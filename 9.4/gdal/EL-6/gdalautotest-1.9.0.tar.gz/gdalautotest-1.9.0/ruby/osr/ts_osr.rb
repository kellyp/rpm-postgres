#!/usr/bin/env ruby

require 'test/unit'
require 'tc_osr_basic'
require 'tc_osr_ct'
require 'tc_osr_ct_proj'
require 'tc_osr_esri'
require 'tc_osr_pci'
require 'tc_osr_proj4'
require 'tc_osr_usgs'
